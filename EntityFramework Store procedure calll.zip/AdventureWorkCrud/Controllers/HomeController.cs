﻿using AdventureWorkCrud.Data;
using AdventureWorkCrud.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace AdventureWorkCrud.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _db;
        public HomeController(ILogger<HomeController> logger, ApplicationDbContext dbContext)
        {
            _logger = logger;
            _db = dbContext;
        }

        public IActionResult GetAll() {
            List<Product> list;
            string sql = "EXEC SalesLT.Product_GetAll";
            list = _db.Products.FromSqlRaw<Product>(sql).ToList();
            Debugger.Break();
            return View("Index");
                
         }

        public IActionResult GetAProduct() {


            List<Product> list;
            string sql = "EXEC SalesLT.Product_Get @ProductID";

            List<SqlParameter> parms = new List<SqlParameter>()
            {
                // Create parameter(s)
                    new SqlParameter { ParameterName = "@ProductID", Value = 706 }

            };
            list = _db.Products.FromSqlRaw<Product>(sql, parms.ToArray()).ToList();
            Debugger.Break();
            return View("Index");


        }

    
        public IActionResult CountAll() {
            ScalarInt value;
            string sql = "EXEC SalesLT.Product_CountAll";
            value = _db.ScalarIntValue.FromSqlRaw<ScalarInt>(sql).AsEnumerable().FirstOrDefault();

            Debugger.Break();
            return View("Index");

        }


        public IActionResult UpdateListPrice()
        {
            int rowAffected;

            string sql = "EXEC SalesLT.Product_UpdateListPrice @ProductID, @ListPrice";

            List<SqlParameter> parms = new List<SqlParameter>
            { 
                // Create parameters    
                new SqlParameter { ParameterName = "@ProductID", Value = 706 },
                new SqlParameter { ParameterName = "@ListPrice", Value = 1500 }
            };


            rowAffected = _db.Database.ExecuteSqlRaw(sql, parms.ToArray());
            Debugger.Break();
            return View("Index");

        }

        public IActionResult MultipleResultSets() {
            List<Product> black = new List<Product>();

            List<Product> red = new List<Product>();

            DbCommand cmd;
            DbDataReader reader;

            string sql = "EXEC SalesLT.MultipleResultsColors";

            cmd = _db.Database.GetDbConnection().CreateCommand();
            cmd.CommandText = sql;

            _db.Database.OpenConnection();

            reader = cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection);

            while (reader.Read())
            {
                black.Add(new Product
                {
                    ProductID = reader.GetInt32(0),
                    Name = reader.GetString(1),
                    ProductNumber = reader.GetString(2)
                });


            }

            reader.NextResult();


            while (reader.Read())
            {
                red.Add(new Product
                {
                    ProductID = reader.GetInt32(0),
                    Name = reader.GetString(1),
                    ProductNumber = reader.GetString(2)
                });


            }

            reader.Close();



            Debugger.Break();
            return View("Index");

        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
